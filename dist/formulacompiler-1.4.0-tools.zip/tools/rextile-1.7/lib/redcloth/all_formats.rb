$:.unshift(File.dirname(__FILE__) + "/../")

require 'redcloth'
require 'redcloth/docbook'
