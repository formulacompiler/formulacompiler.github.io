$:.unshift(File.dirname(__FILE__))

require 'redcloth/base'
require 'redcloth/textile'
require 'redcloth/markdown'
