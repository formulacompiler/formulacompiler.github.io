
# Use Rextile's default template.
@template_path = "#{INSTALL_PATH}/templates/standard"

# Keep make-dependency information
@dependency_info = "../temp/sample.deps"
