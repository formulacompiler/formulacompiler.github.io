
# Use Rextile's default template.
@template_path = "#{INSTALL_PATH}/templates/standard"
